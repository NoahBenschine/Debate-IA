
module.exports = {
  env: {
    NEXTAUTH_URL: process.env.NEXTAUTH_URL,
  },

  reactStrictMode: true,
}
